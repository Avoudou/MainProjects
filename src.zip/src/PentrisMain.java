
public class PentrisMain {

	public static void main(String[] args) {
		//TODO implement

	}

}
