import java.util.Timer;
import java.util.TimerTask;




public class PentrisGameBoard  { 

	private int x;
	private int y;
	private int[][] pentrisGameBoard = new int[y][x];
	private  final int defaultXpoint=3;
	private final int defaultYpoint=0;
	private int  shapeCoordX = defaultXpoint;
	private int  shapeCoordY=defaultYpoint;
	private int[][] shapeActive={{11,11},{11,11}};
	
	 private Timer timer;
	 private   TimerTask myTask;
	   
	  
   
	/**
	 * Constructor makes a game board for pentris of the given
	 * coordinates,marking the boarder with integer value "99"
	 */
	public PentrisGameBoard(int xCoord, int yCoord) {
		x = xCoord + 2;
		y = yCoord + 6;
		pentrisGameBoard = new int[y][x];
		for (int i = 0; i < x; i++) {
			this.pentrisGameBoard[y - 2][i] = 99;
		}
		for (int j = 0; j < y; j++) {
			this.pentrisGameBoard[j][0] = 99;
			this.pentrisGameBoard[j][x - 1] = 99;
		}
		
		timer= new Timer();
		myTask= new TimerTask() {
	    	
	    	
		      @Override
		      public void run() {
		  moveShapeDownStep();
		  printPentrisBoard();
		
		System.out.println(getYshapecoordY());
		
		 
		      }
		    };
		    timer.schedule(myTask, 0, 200);
	}

	/** print the pentris game board accordingly so is understandable in console */
	public void printPentrisBoard() {
		for (int i = 0; i < y; i++) {
			System.out.println();
			for (int j = 0; j < x; j++) {
				if (pentrisGameBoard[i][j] == 0) {
					System.out.print(" " + pentrisGameBoard[i][j] + " ");
				} else {
					System.out.print(pentrisGameBoard[i][j] + " ");
				}
			}
		}

	}

	/**
	 * inserts a desired shape into the board its center matching given
	 * shape coordinates and moving it into the board if the coordinates given don't
	 * match the board width and height(top side)
	 */
	public void insertShapeIntoPos() {
		// way to start from the shape middle (or closest to)the shape and insert it into
		// the board array
		int shapeMidPosition = (int) (shapeActive[0].length - 1) / 2;
		
		if (shapeCoordX - shapeMidPosition < 1) {
			shapeCoordX = 1 + shapeMidPosition;
		}
		if (shapeCoordX - shapeMidPosition + shapeActive[0].length > pentrisGameBoard[0].length - 1) {
			shapeCoordX = pentrisGameBoard[0].length - shapeActive[0].length
					+ shapeMidPosition - 1;
		}
		if (shapeCoordY < shapeActive.length - 1) {
			shapeCoordY = shapeActive.length - 1;
		}
		
		
		for (int shapeIndexY = shapeActive.length - 1; shapeIndexY >= 0; shapeIndexY--) {
			for (int shapeIndexX = 0; shapeIndexX <= shapeActive[0].length - 1; shapeIndexX++) {
				if(shapeActive[shapeIndexY][shapeIndexX]!=0){
				pentrisGameBoard[shapeCoordY + shapeIndexY - shapeActive.length
						+ 1][shapeCoordX - shapeMidPosition + shapeIndexX] = shapeActive[shapeIndexY][shapeIndexX];
				// System.out.println(shapeIndexX+" "+shapeIndexY);
				}
			}
		}

	}

	/** Deletes chosen shape from  position given by x-shape,y-shape coordinates in the game board */
	public void deleteShapeFromPos() {
		// way to start from the shape middle (or closest to)the shape and insert it into
				// the board array
	int shapeMidPosition = (int) (shapeActive[0].length - 1) / 2;
		
		if (shapeCoordX - shapeMidPosition < 1) {
			shapeCoordX = 1 + shapeMidPosition;
		}
		if (shapeCoordX - shapeMidPosition + shapeActive[0].length > pentrisGameBoard[0].length - 1) {
			shapeCoordX = pentrisGameBoard[0].length - shapeActive[0].length
					+ shapeMidPosition - 1;
		}
		if (shapeCoordY < shapeActive.length - 1) {
			shapeCoordY = shapeActive.length - 1;
		}
		
		
		for (int shapeIndexY = shapeActive.length - 1; shapeIndexY >= 0; shapeIndexY--) {
			for (int shapeIndexX = 0; shapeIndexX <= shapeActive[0].length - 1; shapeIndexX++)
				if (shapeActive[shapeIndexY][shapeIndexX] != 0) {
					pentrisGameBoard[shapeCoordY + shapeIndexY
							- shapeActive.length + 1][shapeCoordX
							- shapeMidPosition + shapeIndexX] = 0;
					//System.out.println(getshapecoordX());
				}

			}
		}


	/**Moves a shape one step(index) Left to the x axis if the move is valid,or its previous position if not */
	public void moveShapeLeftStep() {
		// way to start from the shape middle (or closest to)the shape and insert it into
				// the board array
		int shapeMidPosition = (int) (shapeActive[0].length - 1) / 2;
		if (shapeCoordX - shapeMidPosition < 1) {
			shapeCoordX = 1 + shapeMidPosition;
		}
		deleteShapeFromPos();
		shapeCoordX--;
		if (checkShapePlacement()) {
			insertShapeIntoPos();
		} else {
			shapeCoordX++;
			insertShapeIntoPos();
		}
	}
	/**Moves a shape  one step(index) right to the x axis if the move is valid,or its previous position if not */
	public void moveShapeRightStep() {
		// way to start from the shape middle (or closest to)the shape and insert it into
				// the board array
		int shapeMidPosition = (int) (shapeActive[0].length - 1) / 2;
		if (shapeCoordX - shapeMidPosition + shapeActive[0].length > pentrisGameBoard[0].length - 1) {
			shapeCoordX = pentrisGameBoard[0].length - shapeActive[0].length
					+ shapeMidPosition - 1;
		}
		deleteShapeFromPos();
		shapeCoordX++;
		if (checkShapePlacement()) {
			insertShapeIntoPos();

		} else {
			shapeCoordX--;
			insertShapeIntoPos();
		}

	}
/**Moves a shape  one step(index) down to the y axis if the move is valid */
	public void moveShapeDownStep() {
		deleteShapeFromPos();
		shapeCoordY++;
		if (checkShapePlacement()) {
			insertShapeIntoPos();
			
		}
		else{
			shapeCoordY--;
			insertShapeIntoPos();
			shapeCoordY=defaultYpoint;
			if(gameOver()){		
				System.out.println("gameOver");
				timer.cancel();
		
			}
		
		}
		
	}

	/**
	 boolean to determine the end of the game(returns true when game is over)
	 */
	public boolean gameOver() {
		int gameOverLimit = 1;

		for (int shapeIndexY = 0; shapeIndexY <= gameOverLimit; shapeIndexY++) {
			for (int shapeIndexX = 1; shapeIndexX < pentrisGameBoard[0].length-1; shapeIndexX++)
				if (pentrisGameBoard[shapeIndexY][shapeIndexX] != 0) {

					return true;
				}

		}

		return false;
	}

	/**Returns True  if a shape can be placed in given x , y coordinates(checks that no index position not already occupied)*/
	public boolean checkShapePlacement(){
		// way to start from the shape middle (or closest to)the shape and insert it into
				// the board array
		int shapeMidPosition = (int) (shapeActive[0].length - 1) / 2;
		if (shapeCoordX - shapeMidPosition < 1) {
			shapeCoordX = 1 + shapeMidPosition;
		}
		if (shapeCoordX - shapeMidPosition + shapeActive[0].length > pentrisGameBoard[0].length - 1) {
			shapeCoordX = pentrisGameBoard[0].length - shapeActive[0].length
					+ shapeMidPosition - 1;
		}
		if (shapeCoordY < shapeActive.length - 1) {
			shapeCoordY = shapeActive.length - 1;
		}
		
		for (int shapeIndexY = 0; shapeIndexY < shapeActive.length; shapeIndexY++) {
			for (int shapeIndexX = 0; shapeIndexX <shapeActive[0].length; shapeIndexX++){
				if(shapeActive[shapeIndexY][shapeIndexX] != 0 && pentrisGameBoard[shapeCoordY + shapeIndexY - shapeActive.length
				                                              						+ 1][shapeCoordX - shapeMidPosition + shapeIndexX] !=0 ){
					return false;
				}
			}
		}
		return true;
	}
	/**returns the  coordinate x-axis  of where  the chosen shape is/will appear*/ 
	public int getshapecoordX() {
		return shapeCoordX;
	}
	/**returns the  coordinate y-axis  of where  the chosen shape is/will appear*/ 
	public int getYshapecoordY() {
		return shapeCoordY;
	}
	/**sets the  coordinate in x-axis  of where  the chosen shape is/will appear*/ 
	public void setshapecoordX(int start) {
		 shapeCoordX=start;
	}
	/**sets the  coordinate in y-axis  of where  the chosen shape is/will appear*/ 
	public void setshapecoordY(int start) {
		 shapeCoordY= start;
	}
	public void setActiveShape(int[][]chooseShape){
		shapeActive= chooseShape;
		
	}
	
}
