

public class TestVariusPentris {
	

	public static void main(String[] args) {
	
		PentrisGameBoard pentrisBoard = new PentrisGameBoard(5, 8);
		
		
		


	}
}
	

