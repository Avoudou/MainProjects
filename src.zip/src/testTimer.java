
public class testTimer {
	public static void  main (String[] args){
		int x=1;
		x++;
		System.out.println(x);
	}

}
